/* ********** Debut du fichier vulnerable.c ********** */ 
   /* Exemple de programme vulnerable 
    * Auteur : Eric Gingras 
    * Derniere revision : 18 avril 2004 
    */ 
   #include <stdio.h> 
   #include <unistd.h> 
   #include <string.h> 
   int main(int argc, char *argv[]) 
   { 
        char tampon[128]; 
        if(argc < 2) 
        { 
                printf("COPIE NON EXECUTE...\n"); 
                printf("Syntax: %s <donnees a copier>\n", argv[0]);
                exit(0); 
        } 
        strcpy(tampon, argv[1]); 
        printf("tampon = %s\n", tampon); 
        printf("COPIE REUSSIE...\n"); 
        return 0; 
   } 
