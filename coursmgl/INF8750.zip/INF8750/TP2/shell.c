/* ********** Debut du fichier shell.c ********** */ 
   #include <unistd.h> 
   void main() 
   { 
           char *shell[2]; 
           shell[0] = "/bin/sh"; 
           shell[1] = NULL; 
           execve(shell[0], shell, NULL); 
   } 
   /* ********** Fin du fichier shell.c ********** */ 
