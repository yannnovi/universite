/////////////////
// Programme 1 //
/////////////////

// Generation d'un paquet IP qui encapsule un paquet
// ICMP "echo request"(application PING).

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <string.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <ctype.h>
#include <unistd.h>

#define iphdr ip
#define icmphdr icmp
//#define perror printf
unsigned short in_chksum(unsigned short *, int);
// Fonction qui retourne le "checksum Internet" calcul�
// sur les donn�es pass�es en param�tres (adresse m�moire
// du d�but des donn�es, taille).
/* Check Sum */
unsigned short ip_sum(unsigned short *addr, int len)
{
  int sum = 0;
  unsigned short answer = 0;
  
  while (len > 1){
    sum += *addr++;
    len -= 2;
  }
  if (len == 1){
    *(unsigned char *)(&answer) = *(unsigned char *)addr;
    sum += answer;
  }
  sum = (sum >> 16) + (sum & 0xffff); /* add hi 16 to low 16 */
  sum += (sum >> 16);                 /* add carry */
  answer = ~sum;                      /* truncate to 16 bits */
  return(answer);
}

int main (int argc, char * argv[])
{
   //Declarations
        int sock;
        int rc;
        int num;
        struct sockaddr_in addrsock_source;
        struct sockaddr_in addrsock_dest;
        struct iphdr *ip;
        struct icmphdr *icmp;
        char *packet;
        int psize;

   //Verification de la syntaxe de l'appel
        if (argc != 4)
        {
         printf("Syntaxe : executable adresse-IP-source adresse-IP-dest taille");
         exit(1);
        }

   //Recuperation de la taille
        psize= atoi(argv[3]);                                  // Taille du paquet
        if (psize > 1472)
        {
          printf("taille incorrect (taille permise entre 1 et 1472)\n");
          exit(-1);
        }


   //Creation de la structure d'adressage pour la socket
        addrsock_source.sin_addr.s_addr = inet_addr(argv[1]);  // adresse source
        addrsock_dest.sin_addr.s_addr = inet_addr(argv[2]);    // adresse destination
        addrsock_source.sin_family = AF_INET;                  // Connection de type AF_INET
        addrsock_dest.sin_family = AF_INET;                    // Connection de type AF_INET
        addrsock_source.sin_port = htons(0);                   // Port source = 0
        addrsock_dest.sin_port = htons(0);                     // Port destination = 0

   //Cr�ation de la socket
        sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);         // protocole = RAW IP
        if (sock < 0)
        {
         perror("Erreur lors de la cr�ation de la Socket");
         exit(-1);
	}

   //Generation d'un espace m�moire de la taille du paquet (entete IP + entete ICMP + donn�es)
        packet = (char*)malloc(sizeof(struct iphdr) + sizeof(struct icmphdr) + psize);
        ip = (struct iphdr *) packet;
        icmp = (struct icmphdr *) (packet + sizeof(struct iphdr));

   //Initialisation � 0 de tous le bloc m�moire
        memset(packet, 0, sizeof(struct iphdr) + sizeof(struct icmphdr) + 
psize);

   //Construction des entetes IP & ICMP
        ip->ip_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr) + 
psize);
        ip->ip_hl = 5;
        ip->ip_v = 4;
        ip->ip_ttl = 255;
        ip->ip_tos = 0;
        ip->ip_off = 0;
        ip->ip_p = IPPROTO_ICMP;
        //ip->ip_src = addrsock_source.sin_addr.s_addr;
        ip->ip_src = addrsock_source.sin_addr;
		//ip->ip_dst = (in_addr)addrsock_dest.sin_addr.s_addr;
		ip->ip_dst = addrsock_dest.sin_addr;
        ip->ip_sum = ip_sum((unsigned short *)ip, sizeof(struct iphdr));
        icmp->icmp_type = 8;
        icmp->icmp_code = 0;
        icmp->icmp_cksum = in_chksum((unsigned short *)icmp, sizeof(struct icmphdr) + psize);

   //Envoi du paquet
        rc=sendto(sock, packet, sizeof(struct iphdr) + sizeof(struct icmphdr) + psize, 0, (struct sockaddr *)&addrsock_dest, sizeof(struct sockaddr));
        printf("Nombre de bits transmis : %d\n",rc);

   //Liberation de la m�moire
        free(packet);
}




// Fonction qui calcule la valeur d'un checksum Internet
unsigned short in_chksum (unsigned short *addr, int len)
{
        register int nleft = len;
        register int sum = 0;
        u_short answer = 0;

        while (nleft > 1)
        {
          sum += *addr++;
          nleft -= 2;
        }

        if (nleft == 1)
        {
          *(u_char *)(&answer) = *(u_char *)addr;
          sum += answer;
        }

        sum = (sum >> 16) + (sum + 0xffff);
        sum += (sum >> 16);
        answer = ~sum;
        return(answer);
}

