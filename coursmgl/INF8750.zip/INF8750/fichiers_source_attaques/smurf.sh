#/bin/sh
inter=0
while [ $inter -lt $1 ]
do
	echo "ping fait"
	inter=`expr $inter + 1`
	./ex1 $2 $3 1400 &
done	
	 