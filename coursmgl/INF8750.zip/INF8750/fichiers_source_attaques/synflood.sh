#/bin/sh
inter=0
while [ $inter -lt $1 ]
do
	echo "TCP SYN: $2:$inter"
	inter=`expr $inter + 1`
	./ex4 localhost $2 $inter &
done	
