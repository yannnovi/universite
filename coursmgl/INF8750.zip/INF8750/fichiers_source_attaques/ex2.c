/////////////////
// Programme 2 //
/////////////////

// Generation d'un paquet IP qui encapsule un paquet
// ICMP "echo request"(PING) fragment� (2 fragments).

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <string.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <ctype.h>
#include <unistd.h>


unsigned short in_chksum(unsigned short *, int);
// Fonction qui retourne le "checksum Internet" calcul�
// sur les donn�es pass�es en param�tres (adresse m�moire
// du d�but des donn�es, taille).
#define iphdr ip
#define icmphdr icmp

int main (int argc, char * argv[])
{
   //Declarations
        int sock;
        int rc;
        int num;
        struct sockaddr_in addrsock_source;
        struct sockaddr_in addrsock_dest;
        struct iphdr *ip;
        struct icmphdr *icmp;
        char *packet;
        int psize;

   //Verification de la syntaxe de l'appel
        if (argc != 4)
        {
          perror("Syntaxe : executable adresse-IP-source adresse-IP-dest taille\n");
          exit(1);
        }

   //Recuperation de la taille
        psize= atoi(argv[3]);                                  //Taille du packet

        if (psize > 2952 || psize < 1476)
        {
          printf("taille incorrect (taille permise entre 1476 et 2952)\n");
          exit(-1);
        }

   //Creation de la structure d'adressage pour la socket
        addrsock_source.sin_addr.s_addr = inet_addr(argv[1]);  // adresse source
        addrsock_dest.sin_addr.s_addr = inet_addr(argv[2]);    // adress destination
        addrsock_source.sin_family = AF_INET;                  // Connection de type AF_INET
        addrsock_dest.sin_family = AF_INET;                    // Connection de type AF_INET
        addrsock_source.sin_port = htons(0);                   // Port source = 0
        addrsock_dest.sin_port = htons(0);                     // Port destination = 0

   //Creation de la socket
        sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);         // protocole = RAW IP
        if (sock < 0)
        {
          perror("Erreur lors de la cr�ation de la Socket");
          exit(-1);
        }

   //Generation d'un espace m�moire de la taille du paquet (entete IP + entete ICMP + donn�es)
        packet = (char*)malloc(sizeof(struct iphdr) + sizeof (struct icmphdr) + psize);
        ip = (struct iphdr *) packet;
        icmp = (struct icmphdr *) (packet + sizeof(struct iphdr));

   //Initialisation � 0 de tous le bloc m�moire
        memset(packet, 0, sizeof(struct iphdr) + sizeof(struct icmphdr) + psize);

   //Construction des entetes IP & ICMP (premier fragment)
        ip->ip_len = htons(1500);
        ip->ip_hl = 5;
        ip->ip_v = 4;
        ip->ip_ttl = 255;
        ip->ip_tos = 0;
        ip->ip_id= htons(62500);                                  // "id" choisi al�atoirement
        ip->ip_off = htons(0x2000);                          // bit "More Fragment"
        ip->ip_p = IPPROTO_ICMP;
        ip->ip_src = addrsock_source.sin_addr;
        ip->ip_dst = addrsock_dest.sin_addr;
        ip->ip_sum = in_chksum((unsigned short *)ip, sizeof(struct iphdr));
        icmp->icmp_type = 8;
        icmp->icmp_code = 0;
        icmp->icmp_hun.ih_idseq.icd_id = htons(0x0000);
        icmp->icmp_cksum = in_chksum((unsigned short *)icmp, sizeof(struct 
icmphdr) + psize);

   //Envoi du paquet (premier fragment)
        rc=sendto(sock, packet, 1500, 0, (struct sockaddr *)&addrsock_dest, sizeof(struct sockaddr));
        printf("Nombre de bits transmis : %d\n",rc);

   //Construction de l'entete IP (deuxieme fragment)
        ip->ip_len = htons(sizeof(struct iphdr) + psize - 1472);
        ip->ip_id= htons(62500);                                  // "id" doit �tre le m�me !
        ip->ip_off = htons(0x00a9);                          // Offset=((1500(MTU)-20(En tete IP)) >> 3)  & ! More Fragment
        ip->ip_sum = in_chksum((unsigned short *)ip, sizeof(struct iphdr));

   //Envoi du paquet (deuxieme fragment)
        rc=sendto(sock, packet, sizeof(struct iphdr) + psize - 1472, 0, (struct sockaddr *)&addrsock_dest, sizeof(struct sockaddr));
        printf("Nombre de bits transmis : %d\n",rc);

   //Liberation de la m�moire
        free(packet);
}


// Fonction qui calcule la valeur d'un checksum
unsigned short in_chksum (unsigned short *addr, int len)
{
        register int nleft = len;
        register int sum = 0;
        u_short answer = 0;

        while (nleft > 1)
        {
          sum += *addr++;
          nleft -= 2;
        }

        if (nleft == 1)
        {
          *(u_char *)(&answer) = *(u_char *)addr;
          sum += answer;
        }

        sum = (sum >> 16) + (sum + 0xffff);
        sum += (sum >> 16);
        answer = ~sum;
        return(answer);
}


