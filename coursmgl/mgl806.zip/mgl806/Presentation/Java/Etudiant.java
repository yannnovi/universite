package jml;

public class Etudiant {
	
	/**
	 * <pre><jml>
	 *
	 * private invariant this.codePermanent.length() == 12;
	 *
	 * </jml></pre>
	 */
	
	private String nom;
	private String prenom;
	private String codePermanent;
	private String courriel;
	
	/**
	 * Constructeur avec param�tres pour la construction d'un �tudiant
	 * @param nom
	 * @param prenom
	 * @param codePermanent
	 * @param courriel
	 * 
	 */
	public Etudiant(String unNom, String unPrenom, String unCodePermanent,
			String unCourriel) {
		
		this.nom = unNom;
		this.prenom = unPrenom;
		this.codePermanent = unCodePermanent;
		this.courriel = unCourriel;
	}
	
	/**
	 * @return nom
	 */
	public String getNom() {
		return nom;
	}
	
	/**
	 * @param nom le nom � modifier
	 */
	public void setNom(String unNom) {
		this.nom = unNom;
	}
	
	/**
	 * @return prenom
	 */
	public String getPrenom() {
		return prenom;
	}
	
	/**
	 * @param prenom le nom � modifier
	 */
	public void setPrenom(String unPrenom) {
		this.prenom = unPrenom;
	}
	
	/**
	 * @return codePermanent
	 */
	public String getCodePermanent() {
		return codePermanent;
	}
	
	/**
	 * @param codePermanent le code permanent � modifier
	 */
	public void setCodePermanent(String unCodePermanent) {
		this.codePermanent = unCodePermanent;
	}
	
	/**
	 * @return courriel
	 */
	public String getCourriel() {
		return courriel;
	}
	
	/**
	 * @param courriel le courriel � modifier
	 */
	public void setCourriel(String unCourriel) {
		this.courriel = unCourriel;
	}
	
	public static void main(String[] args) {
		Etudiant etudiant1;
		
		// Invariant codePermanent.length() == 12 OK
		System.out.println("Invariant codePermanent.length() == 12 OK");
		etudiant1 = new Etudiant("Riopel","Matthieu", "RIOM02127809", "riomat@sympatico.ca");
		System.out.println(etudiant1.getNom());
		System.out.println(etudiant1.getCodePermanent());
		
		// Invariant codePermanent.length() == 12 Erreur
		//System.out.println("Invariant codePermanent.length() == 12 Erreur");
		//etudiant1 = new Etudiant("Riopel","Matthieu", "ROM02127809", "riomat@sympatico.ca");
		//System.out.println(etudiant1.getNom());
		//System.out.println(etudiant1.getCodePermanent());
	}

}
