package jml;
//@ model import org.jmlspecs.models.*;

public class NoteFinale {
	/**
	 * <pre><jml>
	 *
	 * private invariant note >= 0 && note <= 100;
	 *
	 * private constraint note >= \old(note) ;
	 *
	 * </jml></pre>
	 */

	// Valeur de la note
	private int note;
		
	/**
	 * Retourne la valeur de de la note
	 * La notation pure nous permet d'utiliser une m�thode
	 * dans une sp�cification en nous assurant qu'elle n'aura
	 * pas d'effet de bord. On ne peut en aucun cas faire appel
	 * � une m�thode dans une sp�cification lorsqu'elle n'est
	 * pas d�clar�e pure. Dans le cas pr�sent, comme c'est une m�thode
	 * qui retourne la valeur de la note, il n'y a aucun effet
	 * de bord possible.
	 */
	public /*@ pure */ int getNote() {
		return note ;
	}
	
	/**
	 * Ajuste la valeur de la note
	 * 
	 * @param uneNote la valeur de la note
	 * 
	 * Voici une autre notation qui est tout aussi valable
	 */
	/* @requires uneNote >= 0 && uneNote <= 100 ;
	   @ensures getNote() == uneNote;
	   @ assignable note; @*/
	public void setNote(int uneNote) throws Debordement{
		if (uneNote >= 0 && uneNote <= 100) {
			this.note = uneNote;
	    	// Une assertion permet de s'assurer � l'instant pr�sent que ce qui est
			// sp�cifi� est recpect�
	    	//@ assert uneNote >= 0 && uneNote <= 100;
	    } else {
	    	throw new Debordement() ;
	    }
	}
	
	/**
	 * Incr�mente la valeur de ce compteur de n.
	 * S'assurer que la notre est sup�rieure ou �gale � 0
	 * De plus, la nouvelle note incr�ment�e doit-�tre
	 * �gale � l'ancienne plus la valeur � ajouter.
	 * 
	 * Dans le cas d'un d�bordement donc que la note d�passe 100
	 * qui est un invariant, on lance une exception de d�bordement
	 * et on remet la valeur de la note � son ancienne valeur.
	 * 
	 * <pre><jml>
	 *
	 * requires n >= 0 ;
	 *
	 * ensures getNote() == \old(getNote()) + n ;
	 *
	 * signals (Debordement deb) getNote() == \old(getNote()) ;
	 *
	 * </jml></pre>
	 */
	public void incrNote(int n) throws Debordement {
		int nouvelle_valeur = getNote() + n ;
	    //if (nouvelle_valeur >= 0) {
		if (nouvelle_valeur >= 0 && nouvelle_valeur <= 100) {
	    	setNote(nouvelle_valeur);
	    	//@ assert getNote() >= 0 && getNote() <= 100; 
	    } else {
	    	throw new Debordement() ;
	    }
	}
		
	public static void main(String[] args) {
		NoteFinale uneNote = new NoteFinale();
		
		// Affichage de la note de d�part
		System.out.println(uneNote.getNote());
		
		// Saisir une valeur de la note � l'int�rieur de l'intervalle permise
		try{
			uneNote.setNote(10);
		}catch(Exception e){
			System.out.println("Debordement");
		}
		System.out.println(uneNote.getNote());
		
		// Incr�menter la valeur de la note avec une valeur
		// qui la fera d�passer l'intervalle permise
		// Ceci l�vera l'exception de d�bordement
		try{
			uneNote.incrNote(110);
		}catch(Exception e){
			System.out.println("Debordement");
		}
		
		// Affichage de la note apr�s d�bordement pour montrer qu'elle est rest�e la m�me
		System.out.println(uneNote.getNote());
		
		// Saisir une valeur de la note � l'ext�rieur de l'intervalle permise
		try{
			uneNote.setNote(110);
		}catch(Exception e){
			System.out.println("Debordement");
		}
		
		// Affichage de la note apr�s d�bordement pour montrer qu'elle est rest�e la m�me
		System.out.println(uneNote.getNote());
		
		// Saisir une valeur de la note � l'ext�rieur de l'intervalle permise
		try{
			uneNote.setNote(90);
		}catch(Exception e){
			System.out.println("Debordement");
		}
		
		// Affichage de la note apr�s d�bordement pour montrer qu'elle est rest�e la m�me
		System.out.println(uneNote.getNote());
	}
}
