package jml;

/**
 * Une exception lev�e en cas de d�bordement d'un compteur.
 */

public class Debordement extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L; }

