package jml;

import java.util.*;


public class Equipe {

	/**
	 * <pre><jml>
	 *
	 * private invariant this.vecMembres.size() >= 0 && this.vecMembres.size() <= 4;
	 * 
	 * private invariant this.responsable != null;
	 * 
	 * </jml></pre>
	 */
	
	private String nomEquipe;
	private Etudiant responsable;
    private Vector vecMembres;
	  

	/**
	 * Constructeur avec param�tres pour la construction d'une �quipe
	 * @param nomEquipe
	 * @param responsable
	 */
    /* @ assignable nomEquipe;
       @ assignable responsable;
       @ assignable vecMembres; @*/
	public Equipe(String unNomEquipe, Etudiant unResponsable) {
		
		vecMembres = new Vector();
		
		this.nomEquipe = unNomEquipe;
		this.responsable = unResponsable;
		this.ajouterElement(unResponsable);
	}
	/**
	 * Constructeur bidon pour tester l'invariant responsable
	 *
	 * @param nomEquipe
	 */
	/* @ assignable nomEquipe;
       @ assignable vecMembres; @*/
	public Equipe(String unNomEquipe) {		
		vecMembres = new Vector();
		this.nomEquipe = unNomEquipe;
	}
	
	/**
	 * @return le nom de l'�quipe
	 */
	public String getNomEquipe() {
		return nomEquipe;
	}
	/**
	 * @param unNomEquipe le nom de l'�quipe
	 */
	public void setNomEquipe(String unNomEquipe) {
		this.nomEquipe = unNomEquipe;
	}
	/**
	 * @return le responsable
	 */
	public Etudiant getResponsable() {
		return responsable;
	}
	/**
	 * @param unResponsable le responsable de l'�quipe
	 */
	public void setResponsable(Etudiant unResponsable) {
		this.responsable = unResponsable;
	}
	
	/**
	 * @return le vecteur de membres
	 */
	public /*@ pure */ Vector getVecMembres() {
		return vecMembres;
	}
	
	/**
     * Ajoute l'�l�ment � la collection
     * @param ajout l'objet � rajouter
     */
	/*@ensures this.getVecMembres().size() >= 1 && this.getVecMembres().size() <= 4;
	 */
    public void ajouterElement(Object ajout)
    {
        vecMembres.add(ajout);
    }
    
	/**
     * Retourne le contenu de la collection sous forme d'�num�ration
     * @param aucun
     * @return une �num�ration d'�l�ments.
     */
    public Enumeration retournerContenu()
    {
        return vecMembres.elements();
    }
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// D�claration des �tudiants
		Etudiant etudiant1;
		Etudiant etudiant2;
		Etudiant etudiant3;
		Etudiant etudiant4;
		Etudiant etudiant5;
		
		// D�claration de l'�quipe
		Equipe equipe1;
		
		// Cr�ation du premier �tudiant et affichage des ses informations
		etudiant1 = new Etudiant("Riopel","Matthieu", "RIOM02127809", "riomat@sympatico.ca");
		System.out.println(etudiant1.getNom());
		System.out.println(etudiant1.getCodePermanent());
		
		// Cr�ation de l'�quipe 1 sans responsable pour lever l'invariant responsable
		//equipe1 = new Equipe("Les boys");
		
		// Cr�ation de l'�quipe et ajout du responsable qui est
		// l'�tudiant 1
		equipe1 = new Equipe("Les boys", etudiant1);
		System.out.println(equipe1.getNomEquipe());
		System.out.println(equipe1.getVecMembres().size());
		
		// Cr�ation des autres �tudiants pour les tests
		etudiant2 = new Etudiant("Bourdeau","Yann", "BOUY02127809", "yann@sympatico.ca");
		etudiant3 = new Etudiant("Viau","Jean-Claude", "VIAJ02127809", "jcviau@sympatico.ca");
		etudiant4 = new Etudiant("Rousseau","Simon", "ROUS02127809", "simon@sympatico.ca");
		etudiant5 = new Etudiant("Lamotte","Germain", "LAMG02127809", "la_grosse_motte@sympatico.ca");
		
		// Ajout des �tudiants dans l'�quipe
		equipe1.ajouterElement(etudiant2);
		System.out.println(equipe1.getVecMembres().size());
		
		equipe1.ajouterElement(etudiant3);
		System.out.println(equipe1.getVecMembres().size());
		
		equipe1.ajouterElement(etudiant4);
		System.out.println(equipe1.getVecMembres().size());
		
		// Ajouter un 5 i�me �tudiant dans l'�quipe afin de lever l'invariant pour le
		// nombre d'�tudiants maximum dans l'�quipe
		//equipe1.ajouterElement(etudiant5);
		//System.out.println(equipe1.getVecMembres().size());
	}

}
