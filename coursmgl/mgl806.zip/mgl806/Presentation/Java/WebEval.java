package jml;

public class WebEval {

	/**
	 * Classe de tests pour JML
	 * 
	 * La syntaxe de base de JML est bas�e sur les mots cl�s suivants :
	 *	requires     : D�finit une pr�condition pour la m�thode qui suit.
	 *  ensures      : D�finit une postcondition pour la m�thode qui suit.
	 *  signals      : D�finit une condition d�terminante quand une exception
	 *  		       donn�e peut �tre lanc�e par la m�thode qui suit.
	 *  assignable   : D�finit quels attributs sont assignables par la m�thode qui suit.
	 *  pure         : D�clare une m�thode pure, sans effet de bord.
	 *  invariant    : D�finit une propri�t� invariante de la classe.
	 *  also	     : Permet la d�claration de sur sp�cifications pour 
	 *  			   ajouter aux sp�cifications h�rit�es de la superclasse.
	 *  assert       : D�finit une assertion JML.
	 *
	 * Le JML fournit aussi de base les expressions suivantes :
	 *  \result      : Un identifiant pour la valeur de retour de la m�thode qui suit.
     *  \old(<name>) : Un identifiant pour r�cup�rer l'ancienne valeur (@pre en OCL).
	 *  \forall      : Le quantificateur universel, pour tout.
     *  \exists      : Le quantificateur existentiel, il existe.
	 *  A ==> B      : La relation logique A implique B
	 *  A <==> B     : La relation logique A �quivaut � B 
	 */
	public static void main(String[] args) {
		Etudiant etudiant1;
		
		etudiant1 = new Etudiant("Riopel","Matthieu", "ROM02127809", "riomat@sympatico.ca");
		System.out.println(etudiant1.getNom());
		System.out.println(etudiant1.getCodePermanent());
		

	}

}
