package mypackage1;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface BanqueSessionBMTDEJBHome extends EJBHome 
{
  BanqueSessionBMTDEJB create() throws RemoteException, CreateException;
}