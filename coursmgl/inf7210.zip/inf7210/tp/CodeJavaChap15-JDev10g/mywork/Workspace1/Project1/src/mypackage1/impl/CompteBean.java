package mypackage1.impl;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import mypackage1.ComptePK;
import java.sql.Date;

public class CompteBean implements EntityBean 
{
  public EntityContext entityContext;
  public int nocompte;
  public double solde;
  public Date dateouverture;
  public int noclient;

  public Integer ejbCreate()
  {
    return null;
  }

  public void ejbPostCreate()
  {
  }

  public Integer ejbCreate(int nocompte)
  {
    this.nocompte = nocompte;
    return new Integer(nocompte);
  }

  public void ejbPostCreate(int nocompte)
  {
  }

  public void ejbActivate()
  {
  }

  public void ejbLoad()
  {
  }

  public void ejbPassivate()
  {
  }

  public void ejbRemove()
  {
  }

  public void ejbStore()
  {
  }

  public void setEntityContext(EntityContext ctx)
  {
    this.entityContext = ctx;
  }

  public void unsetEntityContext()
  {
    this.entityContext = null;
  }

  public int getNocompte()
  {
    return nocompte;
  }

  public void setNocompte(int newNocompte)
  {
    nocompte = newNocompte;
  }

  public double getSolde()
  {
    return solde;
  }

  public void setSolde(double newSolde)
  {
    solde = newSolde;
  }

  public Date getDateouverture()
  {
    return dateouverture;
  }

  public void setDateouverture(Date newDateouverture)
  {
    dateouverture = newDateouverture;
  }

  public int getNoclient()
  {
    return noclient;
  }

  public void setNoclient(int newNoclient)
  {
    noclient = newNoclient;
  }
}