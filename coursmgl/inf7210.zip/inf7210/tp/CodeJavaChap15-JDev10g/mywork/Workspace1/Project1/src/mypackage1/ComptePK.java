package mypackage1;
import java.io.Serializable;

public class ComptePK implements Serializable 
{

  public int nocompte;

  public ComptePK()
  {
  }

  public ComptePK(int nocompte)
  {
    this.nocompte = nocompte;
  }

  public boolean equals(Object other)
  {
    // Add custom equals() impl here
    return super.equals(other);
  }

  public int hashCode()
  {
    // Add custom hashCode() impl here
    return super.hashCode();
  }
}