package mypackage1;
import java.io.Serializable;

public class LignecommandePK implements Serializable 
{
  public long noarticle;
  public long nocommande;

  public LignecommandePK()
  {
  }

  public LignecommandePK(long nocommande, long noarticle)
  {
    this.nocommande = nocommande;
    this.noarticle = noarticle;
  }

  public boolean equals(Object other)
  {
    // Add custom equals() impl here
    return super.equals(other);
  }

  public int hashCode()
  {
    // Add custom hashCode() impl here
    return super.hashCode();
  }
}