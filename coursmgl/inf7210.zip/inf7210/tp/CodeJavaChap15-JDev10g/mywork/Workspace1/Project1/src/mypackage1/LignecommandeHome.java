package mypackage1;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import java.util.Collection;

public interface LignecommandeHome extends EJBHome 
{
  Lignecommande create() throws RemoteException, CreateException;

  Lignecommande create(long nocommande, long noarticle, long quantit�) throws RemoteException, CreateException;

  Lignecommande findByPrimaryKey(LignecommandePK primaryKey) throws RemoteException, FinderException;

  Collection findAll() throws RemoteException, FinderException;
}