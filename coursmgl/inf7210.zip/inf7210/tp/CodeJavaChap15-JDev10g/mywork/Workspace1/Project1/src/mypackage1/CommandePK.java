package mypackage1;
import java.io.Serializable;

public class CommandePK implements Serializable 
{
  public long nocommande;

  public CommandePK()
  {
  }

  public CommandePK(long nocommande)
  {
    this.nocommande = nocommande;
  }

  public boolean equals(Object other)
  {
    // Add custom equals() impl here
    return super.equals(other);
  }

  public int hashCode()
  {
    // Add custom hashCode() impl here
    return super.hashCode();
  }
}