package mypackage1;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface BanqueSessionCMTDEJBHome extends EJBHome {
  BanqueSessionCMTDEJB create() throws RemoteException, CreateException;
}