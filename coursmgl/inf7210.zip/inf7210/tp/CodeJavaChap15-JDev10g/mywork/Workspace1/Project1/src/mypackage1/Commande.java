package mypackage1;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;

public interface Commande extends EJBObject 
{
  long getNocommande() throws RemoteException;

  void setNocommande(long newNocommande) throws RemoteException;

  String getDatecommande() throws RemoteException;

  void setDatecommande(String newDatecommande) throws RemoteException;

  long getNoclient() throws RemoteException;

  void setNoclient(long newNoclient) throws RemoteException;
}