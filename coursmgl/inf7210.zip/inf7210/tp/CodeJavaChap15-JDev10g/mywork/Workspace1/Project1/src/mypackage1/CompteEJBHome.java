package mypackage1;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import java.util.Collection;

public interface CompteEJBHome extends EJBHome 
{
  CompteEJB create(int noCompte, java.sql.Date dateOuverture, int noClient) throws RemoteException, CreateException;

  CompteEJB findByPrimaryKey(CompteEJBPK primaryKey) throws RemoteException, FinderException;

  Collection findAll() throws RemoteException, FinderException;

  Collection findByNoClient(int noClient) throws RemoteException, FinderException;
}