package mypackage1;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import mypackage1.CompteEJB;
import mypackage1.CompteEJBHome;
import java.util.Collection;
import java.util.Iterator;
import javax.naming.NamingException;

public class CompteEJBClient 
{
  public static void main(String [] args)
  {
    CompteEJBClient compteEJBClient = new CompteEJBClient();
    try
    {
      Context context = getInitialContext();
      CompteEJBHome compteEJBHome = (CompteEJBHome)PortableRemoteObject.narrow(context.lookup("CompteEJB"), CompteEJBHome.class);
      CompteEJB compteEJB;

      // Use one of the create() methods below to create a new instance
      // compteEJB = compteEJBHome.create( int noCompte, java.sql.Date dateOuverture, int noClient );

      // Call any of the Remote methods below to access the EJB
      // compteEJB.setSolde( double newSolde );
      // compteEJB.setNoClient( int newNoclient );
      // compteEJB.setDateOuverture( java.sql.Date newDateouverture );
      // compteEJB.getSolde(  );
      // compteEJB.getNoCompte(  );
      // compteEJB.getNoClient(  );
      // compteEJB.getDateOuverture(  );

      // Retrieve all instances using the findAll() method
      // (CMP Entity beans only)
      Collection coll = compteEJBHome.findAll();
      Iterator iter = coll.iterator();
      while (iter.hasNext())
      {
        compteEJB = (CompteEJB)iter.next();
        System.out.println("noCompte = " + compteEJB.getNoCompte());
        System.out.println("solde = " + compteEJB.getSolde());
        System.out.println("dateOuverture = " + compteEJB.getDateOuverture());
        System.out.println("noClient = " + compteEJB.getNoClient());
        System.out.println();
      }
    }
    catch(Throwable ex)
    {
      ex.printStackTrace();
    }

  }

  private static Context getInitialContext() throws NamingException
  {
    // Get InitialContext for Embedded OC4J.
    // The embedded server must be running for lookups to succeed.
    return new InitialContext();
  }
}