package mypackage1;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.FinderException;
import java.util.Collection;

public interface CommandeHome extends EJBHome 
{
  Commande create() throws RemoteException, CreateException;

  Commande create(long nocommande, String datecommande, long noclient) throws RemoteException, CreateException;

  Commande findByPrimaryKey(CommandePK primaryKey) throws RemoteException, FinderException;

  Collection findAll() throws RemoteException, FinderException;
}