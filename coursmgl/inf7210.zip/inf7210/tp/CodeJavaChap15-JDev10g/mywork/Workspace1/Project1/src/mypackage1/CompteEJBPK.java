package mypackage1;
import java.io.Serializable;

public class CompteEJBPK implements Serializable {


  public int noCompte;

  // La classe PK doit avoir un constructeur vide (utilis� par le conteneur)
  public CompteEJBPK(){}

  public CompteEJBPK(int noCompte){
    this.noCompte = noCompte;
  }

  public boolean equals(Object unObjet){
    return super.equals(unObjet);
  }

  public int hashCode(){
    return super.hashCode();
  }
}