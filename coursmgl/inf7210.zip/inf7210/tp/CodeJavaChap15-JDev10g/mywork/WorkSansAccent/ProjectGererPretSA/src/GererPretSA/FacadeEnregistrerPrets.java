package GererPretSA;
import java.sql.*;
import java.util.*;

// Fa�ade pour le cas d'utilisation EnregistrerPrets
// Isole la classe de contr�le des details de la gestion de persistence par courtier
// NB Les methodes de la fa�ade doivent etre appelees en sequence
public class FacadeEnregistrerPrets 
{
  private Connection uneConnection;
  private Utilisateur unUtilisateur;
  private Exemplaire unExemplaire;
  private CourtierBDPretEnCours unCourtierBDPretEnCours;
  public FacadeEnregistrerPrets()throws Exception
  {
      // Le constructeur cree la Connection globale pour la fa�ade
      UsineConnection uneUsineConnection = new UsineConnection();
      uneConnection = uneUsineConnection.getConnectionSansAutoCommit(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:orcl",
            "cleratsa","oracle");
  }
  
  // Cherche un Utilisateur avec ses PretsEnCours et retourne
  // les donnees necessaires pour EnregistrerPrets (OTDUtilisateurPrets)
  // Une exception est levee si l'Utilisateur n'existe pas
  public OTDUtilisateurPrets chercherOTDUtilisateurPrets(String idUtilisateur)throws Exception {
  
    // Creation du courtier et dematerialisation de l'Utilisateur
    CourtierBDUtilisateur unCourtierBDUtilisateur = new CourtierBDUtilisateur(uneConnection);
    unUtilisateur = 
        unCourtierBDUtilisateur.chercherUtilisateurParIdUtilisateur(idUtilisateur);
        
    //Creation du courtier et dematerialisation des PretsEnCours
    unCourtierBDPretEnCours = new CourtierBDPretEnCours(uneConnection);
    unCourtierBDPretEnCours.chercherLesPretsEnCours(unUtilisateur);

    // Retourner l'objet de transfert de donnees OTDUtilisateurPrets
    if (unUtilisateur instanceof Membre){
      unCourtierBDUtilisateur.chercherVariablesStatiquesDeMembre();
      Membre unMembre = (Membre)unUtilisateur;
      return new OTDUtilisateurPrets(
                  unMembre.getCategorie(),
                  unMembre.conditionsPretAcceptees(),
                  unMembre.getNbPretsEnCours(),
                  Membre.getNbMaxPrets(),
                  unMembre.getNbRetards());
    } else {
      return new OTDUtilisateurPrets(
        unUtilisateur.getCategorie(),true,unUtilisateur.getNbPretsEnCours(),0,0);
    }
  }

  public String getStatutExemplaire(String idExemplaire)throws Exception{
    // Chercher l'exemplaire en passant par le courtier et retourner le statut
    CourtierBDExemplaire unCourtierBDExemplaire = new CourtierBDExemplaire(uneConnection);
    unExemplaire = unCourtierBDExemplaire.chercherExemplaireParIdExemplaire(idExemplaire);
    return unExemplaire.getStatut();
  }

  // Insere le pret et retourne la date d'enregistrement
  // NB Suppose que unUtilisateur et unExemplaire ont ete dematerialises
  public java.sql.Date insererPretEnCours() throws Exception{
    Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
    java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());
    PretEnCours leNouveauPretEnCours = 
          new PretEnCours(unUtilisateur,dateMaintenant,unExemplaire);

    // Materialiser le PretEnCours dans la BD
    unCourtierBDPretEnCours.insererPretEnCours(leNouveauPretEnCours);
    return dateMaintenant;
  }

  // Confirmer la transaction et fermer la Connection
  public void confirmerTransaction()throws Exception{
    uneConnection.commit();
    uneConnection.close();
  }
}
