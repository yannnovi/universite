package GererPretSA;
import java.sql.*;
import java.util.*;

public class CourtierBDPretEnCours {
    private Connection uneConnection;
   
    // Constructeur pour connexion passee par le createur
    public CourtierBDPretEnCours(Connection laConnection){
        this.uneConnection = laConnection;
    }
    
    public void setConnection(Connection laConnection){
        this.uneConnection = laConnection;
    }

    public void chercherLesPretsEnCours(Utilisateur unUtilisateur)
    // Dematerialiser les PretEnCours d'un Utilisateur 
    throws Exception{
       // Verrouiller la table des prets en cours pour serialisabilite 
        // (Oracle mode READ COMMITTED)
        PreparedStatement unEnonceLock = uneConnection.prepareStatement(
            "LOCK TABLE PretEnCours IN SHARE ROW EXCLUSIVE MODE");
        unEnonceLock.execute();
        unEnonceLock.close();
        PreparedStatement unEnonceSQL = uneConnection.prepareStatement
        ("SELECT datePret,idExemplaire "+
        "FROM PretEnCours WHERE idUtilisateur = ? " );
        String idUtilisateur = unUtilisateur.getIdUtilisateur();
        unEnonceSQL.setString(1,idUtilisateur);
        ResultSet resultatSelect = unEnonceSQL.executeQuery();
        // lesPrets contiendra la collection des objets PretEnCours
        Vector lesPrets = new Vector();
        while (resultatSelect.next ()){
            PretEnCours unPret = new PretEnCours(unUtilisateur,resultatSelect.getDate(1));
            lesPrets.addElement(unPret);
        }
        // Faire les references inverses ! 
        unUtilisateur.setLesPrets(lesPrets);
        unEnonceSQL.close();
    }
    public void insererPretEnCours (PretEnCours unPretEnCours)
    // Materialise un nouveau PretEnCours dans la BD
        throws Exception, SQLException {
        PreparedStatement unEnonceSQL = uneConnection.prepareStatement
        ("INSERT INTO PretEnCours(idExemplaire,idUtilisateur)"+
        "VALUES(?,?)");
        unEnonceSQL.setString(1,unPretEnCours.getIdExemplaire());
        unEnonceSQL.setString(2,unPretEnCours.getIdUtilisateur());
        //NB la date est generee automatiquement par le serveur de BD (default sysdate)
        // et le statut est modifie par un TRIGGER
        int n = unEnonceSQL.executeUpdate();
        unEnonceSQL.close();
        if (n != 1){throw new Exception("Insertion dans PretEnCours a echoue");}
    }
}