package GererPretSA;
import java.util.*;
public class Membre extends Utilisateur {
    private static int nbMaxPrets;
    private static int dureeMaxPret;

    private String telephoneResidence;

    public Membre(String idUtilisateur, String motPasse, String nom,
        String prenom, String categorie, String telephoneResidence){
        super(idUtilisateur, motPasse, nom, prenom, categorie);
        this.telephoneResidence = telephoneResidence;
    }

    public static int getNbMaxPrets(){return nbMaxPrets;}
    public static int getDureeMaxPret(){return dureeMaxPret;}
    public static void setNbMaxPrets(int leNbMaxPrets){nbMaxPrets = leNbMaxPrets;}
    public static void setDureeMaxPrets(int laDureeMaxPret){dureeMaxPret = laDureeMaxPret;}

    public void setTelephoneResidence(String telephoneResidence)
        {this.telephoneResidence = telephoneResidence;}
    public String getTelephoneResidence(){return telephoneResidence;}
    public int getNbRetards(){
        Enumeration enumerationPrets = lesPrets.elements();
        int nbRetards = 0;
        Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
        // Soustrait ensuite la duree maximale en jours pour obtenir la date minimale 
        // avant laquelle il y a un retard
        maintenant.add(Calendar.DATE,-dureeMaxPret); 
        java.sql.Date dateMinSansRetard = new java.sql.Date(maintenant.getTime().getTime());
        while (enumerationPrets.hasMoreElements()){
            Pret unPret = (Pret)enumerationPrets.nextElement();
            if (unPret instanceof PretEnCours){
                if (dateMinSansRetard.after(unPret.getDatePret())){
                    nbRetards++;
                }
            }
        }
        return nbRetards;
    }
    public boolean conditionsPretAcceptees(){
        return (this.getNbRetards() == 0 && this.getNbPretsEnCours() < nbMaxPrets);
    }
}