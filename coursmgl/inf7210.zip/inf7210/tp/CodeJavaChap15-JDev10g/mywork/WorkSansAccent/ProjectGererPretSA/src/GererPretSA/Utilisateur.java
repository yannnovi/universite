package GererPretSA;
import java.util.*;
public class Utilisateur extends Personne {
    protected String idUtilisateur;
    protected String motPasse;
    protected String categorie;
    protected Vector lesPrets; // Association avec Pret

    // Constructeurs pour Utilisateur
    public Utilisateur(String idUtilisateur){
        this.idUtilisateur = idUtilisateur;
    }
    public Utilisateur(String idUtilisateur, String motPasse, String nom,
        String prenom, String categorie){
        super(nom,prenom);
        this.idUtilisateur = idUtilisateur;
        this.motPasse = motPasse;
        this.categorie =  categorie;
    }
    
    public String getIdUtilisateur(){return idUtilisateur;}
    public String getMotPasse(){return motPasse;}
    public String getCategorie(){return categorie;}
    public Vector getLesPrets(){return lesPrets;}
    public int getNbPretsEnCours(){
        Enumeration enumerationPrets = lesPrets.elements();
        int nbPretsEnCours = 0;
        while (enumerationPrets.hasMoreElements()){
            Pret unPret = (Pret)enumerationPrets.nextElement();
            if (unPret instanceof PretEnCours){
                nbPretsEnCours++;
            }
        }
        return nbPretsEnCours;
    }
    
    public void setIdUtilisateur(String idUtilisateur){this.idUtilisateur = idUtilisateur;}
    public void setMotPasse(String motPasse){this.motPasse = motPasse;}
    public void setCategorie(String categorie){this.categorie = categorie;}
    public void setLesPrets(Vector lesPrets){this.lesPrets = lesPrets;}
}