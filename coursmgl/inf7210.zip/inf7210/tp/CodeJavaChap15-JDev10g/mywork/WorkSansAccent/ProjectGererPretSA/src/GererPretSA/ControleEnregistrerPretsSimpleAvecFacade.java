package GererPretSA;
/* Classe de contr�le pour EnregistrerPretsSimple
 * Interface � l'utilisateur minimaliste
 * NB Pas de verification des conditions prealabales dans le programme client
 * Utilise FacadeEnregistrerPretsSimple
 */
import java.sql.*;
import javax.swing.JOptionPane;
import java.util.*;

class ControleEnregistrerPretsSimpleAvecFacade {
  public static void main (String args []) throws Exception {

    // Saisir l'idUtilisateur et l'idExemplaire
    String idUtilisateur = 
      JOptionPane.showInputDialog("Entrez l'identificateur de l'utilisateur: ");
    String idExemplaire = 
      JOptionPane.showInputDialog("Entrez l'identificateur de l'exemplaire:");

    FacadeEnregistrerPretsSimple uneFacadeEnregistrerPretsSimple = null;
    try{
    uneFacadeEnregistrerPretsSimple = new FacadeEnregistrerPretsSimple();
    // Enregistrer le pret en passant par la fa�ade
    java.sql.Date datePret = 
        uneFacadeEnregistrerPretsSimple.insererPretEnCours(idUtilisateur,idExemplaire);
    // Message de confirmation du pret
    JOptionPane.showMessageDialog(null,
      "Pret de l'exemplaire " + idExemplaire +
      " � l'utilisateur " + idUtilisateur + " confirme.\nDate:" + datePret);
    }
    catch(Exception lException){
      JOptionPane.showMessageDialog(null,lException.getMessage());
      lException.printStackTrace();
    }        
    finally{
      System.exit(0);
    }
  }
}