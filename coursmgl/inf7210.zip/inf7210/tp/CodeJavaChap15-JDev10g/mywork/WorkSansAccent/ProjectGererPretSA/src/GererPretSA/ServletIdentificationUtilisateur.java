package GererPretSA;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class ServletIdentificationUtilisateur extends HttpServlet {

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    //Chercher le param�tre idUtilisateur de la form
    String idUtilisateur = "";
    try { idUtilisateur = request.getParameter("idUtilisateur"); }
    catch (Exception e) { e.printStackTrace(); }

    // Creer un objet session si non existant
    HttpSession uneSession = request.getSession(true);

    // Entete de la page de reponse html
    response.setContentType("text/html");
    OutputStreamWriter unOutputStreamWriter = new OutputStreamWriter(response.getOutputStream());
    PrintWriter out = new PrintWriter(unOutputStreamWriter);
      out.println("<html>");
      out.println("<head><title>Reponse de ServletIdentificationUtilisateur</title></head>");
      out.println("<body>");

    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = null;

    try{
      // Ouvrir une Connection
      uneConnection = uneUsineConnection.getConnectionSansAutoCommit(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:orcl",
            "cleratsa","oracle");
      // Dematerialiser l'Utilisateur et ses PretsEnCours
      Membre unMembre = null;

      // Creation du courtier et dematerialisation de l'Utilisateur
      CourtierBDUtilisateur unCourtierBDUtilisateur =
        new CourtierBDUtilisateur(uneConnection);
      Utilisateur unUtilisateur = unCourtierBDUtilisateur.chercherUtilisateurParIdUtilisateur(idUtilisateur);

      //Creation du courtier et dematerialisation des PretsEnCours
      CourtierBDPretEnCours unCourtierBDPretEnCours =
        new CourtierBDPretEnCours(uneConnection);
      unCourtierBDPretEnCours.chercherLesPretsEnCours(unUtilisateur);

      // Affichage de l'idUtilisateur et du nombre de prets
      out.println("Utilisateur :" + idUtilisateur);
      out.println(" Nombre de prets en cours :" + unUtilisateur.getNbPretsEnCours()+"<br>");

      // Verifier si les conditions prealables sont violees
      boolean conditionsAcceptees = false;
      if (unUtilisateur instanceof Membre){
        unCourtierBDUtilisateur.chercherVariablesStatiquesDeMembre();
        unMembre = (Membre)unUtilisateur;
        if (!unMembre.conditionsPretAcceptees()){
          out.println("Pret refuse.<br>Nb de prets :" + unMembre.getNbPretsEnCours()+
                ". Maximum :" + Membre.getNbMaxPrets() +
                ". Nb de retards :" + unMembre.getNbRetards());
          // Liberer la Connection
          uneConnection.commit();
          uneConnection.close();
        }else {conditionsAcceptees = true;}
      }else{conditionsAcceptees = true;}// Pas de contrainte pour un employe
      if(conditionsAcceptees){

        // Sauvegarder les objets du contexte de la session
        uneSession.setAttribute("uneConnection", uneConnection);
        uneSession.setAttribute("unUtilisateur", unUtilisateur);
        uneSession.setAttribute("unCourtierBDPretEnCours", unCourtierBDPretEnCours);


        // Construire la FORM pour saisir l'idExemplaire
        out.println("<form action = \"ServletIdentificationExemplaire\" method = \"post\">");
        out.println("<p>Entrez l'identifiant de l'exemplaire et cliquez Soumettre</p>");
        out.println("<input type = \"text\" name = \"idExemplaire\" />");
        out.println("<input type = \"submit\" value = \"Soumettre\" />");
        out.println("</form>");
      }
    }catch (Exception e) {
      out.println(e.getMessage());
      e.printStackTrace();
    }
    finally{
        out.println("</body></html>");
        out.close();
      // NB garder la connexion ouverte et ne pas terminer la transaction
    }
  }
}