package GererPretSA;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class ServletIdentificationUtilisateurFacade extends HttpServlet {

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    //Chercher le param�tre idUtilisateur de la form
    String idUtilisateur = "";
    try { idUtilisateur = request.getParameter("idUtilisateur"); }
    catch (Exception e) { e.printStackTrace(); }

    // Cr�er un objet session si non existant
    HttpSession uneSession = request.getSession(true);

    // Entete de la page de r�ponse html
    response.setContentType("text/html");
    OutputStreamWriter unOutputStreamWriter = new OutputStreamWriter(response.getOutputStream());
    PrintWriter out = new PrintWriter(unOutputStreamWriter);
      out.println("<html>");
      out.println("<head><title>R�ponse de ServletIdentificationUtilisateurFacade</title></head>");
      out.println("<body>");

    try{
      // Cr�er la facade et chercher l'OTDUtilisateurPrets 
      FacadeEnregistrerPrets uneFacadeEnregistrerPrets = new FacadeEnregistrerPrets();
      OTDUtilisateurPrets unOTDUtilisateurPrets = uneFacadeEnregistrerPrets.chercherOTDUtilisateurPrets(idUtilisateur);

      // Affichage de l'idUtilisateur et du nombre de prets
      out.println("Utilisateur :" + idUtilisateur);
      out.println(" Nombre de prets en cours :" + unOTDUtilisateurPrets.getNbPretsEnCours()+"<br>");

      // V�rifier si les conditions pr�alables sont viol�es
      if (!unOTDUtilisateurPrets.conditionsPretAcceptees()){
          out.println("Pret refus�.<br>Nb de prets :" + unOTDUtilisateurPrets.getNbPretsEnCours()+
                ". Maximum :" + unOTDUtilisateurPrets.getNbMaxPrets() +
                ". Nb de retards :" + unOTDUtilisateurPrets.getNbRetards());
          // Liberer la Connection
        uneFacadeEnregistrerPrets.confirmerTransaction();  
      }else{

        // Sauvegarder les objets du contexte de la session
        uneSession.setAttribute("uneFacadeEnregistrerPrets", uneFacadeEnregistrerPrets);
        uneSession.setAttribute("idUtilisateur", idUtilisateur);

        // Construire la FORM pour saisir l'idExemplaire
        out.println("<form action = \"ServletTerminerPretFacade\" method = \"post\">");
        out.println("<p>Entrez l'identifiant de l'exemplaire et cliquez Soumettre</p>");
        out.println("<input type = \"text\" name = \"idExemplaire\" />");
        out.println("<input type = \"submit\" value = \"Soumettre\" />");
        out.println("</form>");
      }
    }catch (Exception e) {
      out.println(e.getMessage());
      e.printStackTrace();
    }
    finally{
        out.println("</body></html>");
        out.close();
      // NB garder la connexion ouverte et ne pas terminer la transaction
    }
  }
}