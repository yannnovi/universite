package GererPretSA;
/* Classe de contr�le simple pour EnregistrerPrets
 * Securite �par les donnees�
 * Interface � l'utilisateur minimaliste
 * NB Verifie les conditions de pret et le statut de l'exemplaire au niveau du programme client
 */
import java.sql.*;
import javax.swing.JOptionPane;
import java.util.*;

class ControleEnrPretsSecuriteParDonnees {
    public static void main (String args []) throws Exception {
        String idCommis = 
            JOptionPane.showInputDialog("Entrez l'identificateur du commis au pret: ");
        String motDePasse = 
            JOptionPane.showInputDialog("Entrez le mot de passe : ");

        // Creation d'une Connection � partir du idCommis et de son motDePasse
        UsineConnection uneUsineConnection = new UsineConnection();
        Connection uneConnection = uneUsineConnection.getConnectionSansAutoCommit(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:orcl",
            idCommis, motDePasse);
        try{
            // Dematerialiser l'Utilisateur et ses PretsEnCours
            Membre unMembre = null;
            String idUtilisateur = 
                JOptionPane.showInputDialog("Entrez l'identificateur de l'utilisateur: ");

            // Creation du courtier et dematerialisation de l'Utilisateur
            CourtierBDUtilisateur unCourtierBDUtilisateur = 
                new CourtierBDUtilisateur(uneConnection);
            Utilisateur unUtilisateur = 
                unCourtierBDUtilisateur.chercherUtilisateurParIdUtilisateur(idUtilisateur);

            //Creation du courtier et dematerialisation des PretsEnCours
            CourtierBDPretEnCours unCourtierBDPretEnCours = 
                new CourtierBDPretEnCours(uneConnection);
            unCourtierBDPretEnCours.chercherLesPretsEnCours(unUtilisateur);
            JOptionPane.showMessageDialog(null,
            "Nombre de prets en cours :" + unUtilisateur.getNbPretsEnCours());

            // Verifier si les conditions prealables sont acceptees
            boolean conditionsAcceptees = false;
            if (unUtilisateur instanceof Membre){
                unCourtierBDUtilisateur.chercherVariablesStatiquesDeMembre();
                unMembre = (Membre)unUtilisateur;
                if (!unMembre.conditionsPretAcceptees()){
                    JOptionPane.showMessageDialog(null,
                    "Pret refuse\nNb de prets :" + unMembre.getNbPretsEnCours()+
                    ". Maximum :" + Membre.getNbMaxPrets() +
                    "\nNb de retards :" + unMembre.getNbRetards());
                } else {conditionsAcceptees = true;}
            } else {conditionsAcceptees = true;}// Pas de contrainte pour un employe
            if(conditionsAcceptees){
                String idExemplaire = JOptionPane.showInputDialog("Entrez l'identificateur de l'exemplaire:");

                // Verifier statut de l'exemplaire
                CourtierBDExemplaire unCourtierBDExemplaire = 
                    new CourtierBDExemplaire(uneConnection);
                Exemplaire unExemplaire = 
                    unCourtierBDExemplaire.chercherExemplaireParIdExemplaire(idExemplaire);
                if (unExemplaire.getStatut().equals("disponible")){

                    // Generer la date du jour et l'objet PretEnCours
                    Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
                    java.sql.Date dateMaintenant = 
                        new java.sql.Date(maintenant.getTime().getTime());
                    PretEnCours leNouveauPretEnCours = 
                        new PretEnCours(unUtilisateur,dateMaintenant,unExemplaire);

                    // Materialiser le PretEnCours dans la BD
                    unCourtierBDPretEnCours.insererPretEnCours(leNouveauPretEnCours);

                    JOptionPane.showMessageDialog(null,
                    "Pret de l'exemplaire " + idExemplaire +
                    " � l'utilisateur " + idUtilisateur + " confirme.\nDate:" + dateMaintenant
                    );
                }else{
                    JOptionPane.showMessageDialog(null,"Exemplaire non disponible:"+idExemplaire);
                }
            }
        }
        catch(Exception lException){
            JOptionPane.showMessageDialog(null,lException.getMessage());
            lException.printStackTrace();
        }
        finally{
            uneConnection.commit();
            uneConnection.close();
            System.exit(0);
        }
    }
}