package GererPretSA;
import javax.ejb.EJBHome;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

public interface FacadeEnrPretsSessionEJBHome extends EJBHome 
{
  FacadeEnrPretsSessionEJB create() throws RemoteException, CreateException;
}