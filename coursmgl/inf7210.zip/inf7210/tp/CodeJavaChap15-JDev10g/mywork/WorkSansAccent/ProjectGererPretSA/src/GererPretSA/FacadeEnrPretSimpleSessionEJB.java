package GererPretSA;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;
import java.sql.Date;

public interface FacadeEnrPretSimpleSessionEJB extends EJBObject 
{
  Date insererPretEnCours(String idUtilisateur, String idExemplaire) throws RemoteException, Exception;
}