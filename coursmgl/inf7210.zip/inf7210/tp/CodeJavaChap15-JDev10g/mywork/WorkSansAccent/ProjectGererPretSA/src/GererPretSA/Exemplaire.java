package GererPretSA;
public class Exemplaire {
    private String idExemplaire;
    private String statut;

    public Exemplaire(String idExemplaire) {
        this.idExemplaire = idExemplaire;
    }
    public Exemplaire(String idExemplaire,String statut) {
        this.idExemplaire = idExemplaire;
        this.statut = statut;
    }
    public String getStatut(){return statut;}
    public String getIdExemplaire(){return idExemplaire;}
}