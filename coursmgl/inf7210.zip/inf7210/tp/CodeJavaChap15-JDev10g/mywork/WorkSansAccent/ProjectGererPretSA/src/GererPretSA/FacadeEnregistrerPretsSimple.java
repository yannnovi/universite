package GererPretSA;
import java.sql.*;
import java.util.*;

// Fa�ade pour le cas d'utilisation EnregistrerPretsSimple
public class FacadeEnregistrerPretsSimple {
  public FacadeEnregistrerPretsSimple(){}
  
  // Ouvre la connexion avec autocommit, insere le pret, ferme la connexion et
  // retourne la date d'enregistrement
  public java.sql.Date insererPretEnCours(
    String  idUtilisateur, String idExemplaire) throws Exception{
    UsineConnection uneUsineConnection = new UsineConnection();
    Connection uneConnection = uneUsineConnection.getConnection(
            "oracle.jdbc.driver.OracleDriver",
            "jdbc:oracle:thin:@localhost:1521:orcl",
            "cleratsa","oracle");
    Utilisateur unUtilisateur = new Utilisateur(idUtilisateur);
    Exemplaire unExemplaire = new Exemplaire(idExemplaire);
        
    // Generer la date du jour et l'objet PretEnCours
    Calendar maintenant = Calendar.getInstance(); // Calendrier avec date actuelle
    java.sql.Date dateMaintenant = new java.sql.Date(maintenant.getTime().getTime());
    PretEnCours leNouveauPretEnCours = 
            new PretEnCours(unUtilisateur,dateMaintenant,unExemplaire);

    // Materialiser le PretEnCours dans la BD
    CourtierBDPretEnCours unCourtierBDPretEnCours = 
                new CourtierBDPretEnCours(uneConnection);
    unCourtierBDPretEnCours.insererPretEnCours(leNouveauPretEnCours);
    // Pas besoin de commit
    uneConnection.close();
    return dateMaintenant;
  }
}
