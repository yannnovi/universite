package GererPretSA;
import java.util.*;
public class Employe extends Utilisateur {

    private String codeMatricule;
    private String categorieEmploye;

    public Employe(String idUtilisateur, String motPasse, String nom,
        String prenom, String categorie, String codeMatricule, String categorieEmploye){
        super(idUtilisateur, motPasse, nom, prenom, categorie);
        this.codeMatricule = codeMatricule;
        this.categorieEmploye = categorieEmploye;    
    }

    public String getCodeMatricule(){return codeMatricule;}
    public String getCategorieEmploye(){return categorieEmploye;}
    public void setCodeMatricule(String codeMatricule)
        {this.codeMatricule = codeMatricule;}
    public void setCategorieEmploye(String categorieEmploye)
        {this.categorieEmploye = categorieEmploye;}
}