package GererPretSA;
/* Classe de contr�le pour EnregistrerPrets qui passe par FacadeEnregistrerPrets 
 * pour les services m�tiers
 * Interface � l'utilisateur minimaliste
 * NB V�rifie les conditions de pret et le statut de l'exemplaire au niveau du programme client
 */
import java.sql.*;
import javax.swing.JOptionPane;
import java.util.*;

class ControleEnregistrerPretsAvecFacade {
  public static void main (String args []) throws Exception {
    FacadeEnregistrerPrets uneFacadeEnregistrerPrets = new FacadeEnregistrerPrets();
    String idUtilisateur = JOptionPane.showInputDialog("Entrez l'identificateur de l'utilisateur: ");
    try{
      // Chercher les donn�es de l'utilisateur en passant par la fa�ade
      OTDUtilisateurPrets unOTDUtilisateurPrets = uneFacadeEnregistrerPrets.chercherOTDUtilisateurPrets(idUtilisateur);
      JOptionPane.showMessageDialog(null,
            "Nombre de prets en cours :" + unOTDUtilisateurPrets.getNbPretsEnCours());

      // V�rifier si les conditions de pret sont accept�es
      if (!unOTDUtilisateurPrets.conditionsPretAcceptees()){
        JOptionPane.showMessageDialog(null,
            "Pret refus�\nNb de prets :" + unOTDUtilisateurPrets.getNbPretsEnCours()+
            ". Maximum :" + unOTDUtilisateurPrets.getNbMaxPrets() +
            "\nNb de retards :" + unOTDUtilisateurPrets.getNbRetards());
      } else {
        String idExemplaire = 
          JOptionPane.showInputDialog("Entrez l'identificateur de l'exemplaire:");

        // V�rifier le statut de l'exemplaire en passant par la fa�ade
        String statut = uneFacadeEnregistrerPrets.getStatutExemplaire(idExemplaire);
        if (statut.equals("disponible")){

          // Enregistrer le pret en passant par la fa�ade
          java.sql.Date datePret = 
            uneFacadeEnregistrerPrets.insererPretEnCours();

          JOptionPane.showMessageDialog(null,"Pret de l'exemplaire " + idExemplaire +
              " � l'utilisateur " + idUtilisateur + " confirme.\nDate:" + datePret);
        }else{
            JOptionPane.showMessageDialog(null,"Exemplaire non disponible:"+idExemplaire);
        }
      }
    }
    catch(Exception lException){
            JOptionPane.showMessageDialog(null,lException.getMessage());
            lException.printStackTrace();
    }
    finally{
      uneFacadeEnregistrerPrets.confirmerTransaction();
      System.exit(0);
    }
  }
}