package GererPretSA;
import javax.ejb.EJBObject;
import java.rmi.RemoteException;
import java.sql.Date;

public interface FacadeEnrPretsSessionEJB extends EJBObject 
{
  OTDUtilisateurPrets chercherOTDUtilisateurPrets(String idUtilisateur) throws Exception, RemoteException;

  void confirmerTransaction() throws Exception, RemoteException;

  String getStatutExemplaire(String idExemplaire) throws Exception, RemoteException;

  Date insererPretEnCours() throws Exception, RemoteException;

}