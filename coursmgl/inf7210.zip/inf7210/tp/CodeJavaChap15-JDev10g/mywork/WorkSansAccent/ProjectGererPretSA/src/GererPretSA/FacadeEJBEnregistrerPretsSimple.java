package GererPretSA;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import GererPretSA.FacadeEnrPretSimpleSessionEJB;
import GererPretSA.FacadeEnrPretSimpleSessionEJBHome;
import javax.naming.NamingException;

// Fa�ade pour le cas d'utilisation EnregistrerPretsSimple
// La fa�ade utilise les services du EJB session FacadeEnrPretSimpleSessionEJB
public class FacadeEJBEnregistrerPretsSimple 
{
  public FacadeEJBEnregistrerPretsSimple()throws Exception
  {
 }
  // Ins�re le pret et retourne la date d'enregistrement
  public java.sql.Date insererPretEnCours(
    String  idUtilisateur, String idExemplaire) throws Exception{
      // Chercher une r�f�rence au EJB session
      Context context = new InitialContext();
      FacadeEnrPretSimpleSessionEJBHome facadeEnrPretSimpleSessionEJBHome = (FacadeEnrPretSimpleSessionEJBHome)PortableRemoteObject.narrow(context.lookup("FacadeEnrPretSimpleSessionEJB"), FacadeEnrPretSimpleSessionEJBHome.class);
      FacadeEnrPretSimpleSessionEJB uneFacadeEnrPretSimpleSessionEJB;
      uneFacadeEnrPretSimpleSessionEJB = facadeEnrPretSimpleSessionEJBHome.create();

/*  NB Le code suivant ne fonctionne plus avec JDevelopper 10g (fonctionnait avec 9.0.2)
      FacadeEnrPretSimpleSessionEJB uneFacadeEnrPretSimpleSessionEJB;
      Hashtable env = new Hashtable();
      env.put(Context.INITIAL_CONTEXT_FACTORY, "com.evermind.server.rmi.RMIInitialContextFactory");
      env.put(Context.SECURITY_PRINCIPAL, "admin");
      env.put(Context.SECURITY_CREDENTIALS, "welcome");
      env.put(Context.PROVIDER_URL, "ormi://localhost:23893/current-workspace-app");
      Context ctx = new InitialContext(env);
      FacadeEnrPretSimpleSessionEJBHome facadeEnrPretSimpleSessionEJBHome =
        (FacadeEnrPretSimpleSessionEJBHome)ctx.lookup("FacadeEnrPretSimpleSessionEJB");
      uneFacadeEnrPretSimpleSessionEJB = facadeEnrPretSimpleSessionEJBHome.create(  ); 
*/

      // D�l�guer l'insertion du PretEnCours � la methode du EJB
      return uneFacadeEnrPretSimpleSessionEJB.insererPretEnCours(idUtilisateur,idExemplaire);
  }
  private static Context getInitialContext() throws NamingException
  {
    // Get InitialContext for Embedded OC4J.
    // The embedded server must be running for lookups to succeed.
    return new InitialContext();
  }
}
