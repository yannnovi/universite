select functionalSize, normalisedworkeffort, CountApproach from statsprojet where languagetype = '4GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0';


select functionalSize, normalisedworkeffort, CountApproach from statsprojet where languagetype = '3GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0' and ApplicationType like '%Real%';
select projectid,functionalSize, normalisedworkeffort,CountApproach from statsprojet where languagetype = '3GL' and typeofserver like '%Unix%'  and functionalSize != '0';
select functionalSize, normalisedworkeffort from statsprojet where languagetype = '4GL' and typeofserver like '%LAN%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0' and ApplicationType like '%Real%';

select projectID,functionalSize, normalisedworkeffort from statsprojet where functionalsize = '1616' ;

select * from statsprojet where languagetype = '4GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0';

================ unix 4gl
select projectid, ProjectActivityScope, DevelopmentType, Organisationtype,BusinessAreaType,UsedMethodology, MaxTeamSize,Linesofcode,Minordefects,Majordefects,ApplicationType,Architecture, ClientServer,DevelopmentTechniques,DevelopmentPlatform,FirstHardware,SecondHardware ,FirstOperatingSystem, SecondOperatingSystem,FirstDataBaseSystem,SecondDataBaseSystem,FirstComponentServer,SecondComponentServer ,PrimaryProgrammingLanguage,SecondLanguage,functionalSize, normalisedworkeffort  from statsprojet where languagetype = '4GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0';

select projectid,reportedpdr,normalisedworkeffort from statsprojet where languagetype = '4GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0';

select projectid, PrimaryProgrammingLanguage,FirstLanguage,SecondLanguage,FirstOperatingSystem,SecondOperatingSystem  from statsprojet where languagetype = '4GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0';

=============== unix 3gl
select projectid, ProjectActivityScope, DevelopmentType, Organisationtype,BusinessAreaType,UsedMethodology, MaxTeamSize,Linesofcode,Minordefects,Majordefects,ApplicationType,Architecture, ClientServer,DevelopmentTechniques,DevelopmentPlatform,FirstHardware,SecondHardware ,FirstOperatingSystem, SecondOperatingSystem,FirstDataBaseSystem,SecondDataBaseSystem,FirstComponentServer,SecondComponentServer ,PrimaryProgrammingLanguage,SecondLanguage,functionalSize, normalisedworkeffort  from statsprojet where languagetype = '3GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0';

select projectid, FirstHardware,FirstOperatingSystem,FirstDataBaseSystem,FirstComponentServer,PrimaryProgrammingLanguage,functionalSize, normalisedworkeffort  from statsprojet where languagetype = '3GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0';

select projectid, PrimaryProgrammingLanguage,FirstLanguage,SecondLanguage,FirstOperatingSystem,SecondOperatingSystem,DevelopmentTechniques  from statsprojet where languagetype = '3GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0';
===============
lan based 4gl
select *  from statsprojet where languagetype = '4GL' and typeofserver like '%LAN%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0';


================
select * from statsprojet where projectid in ('17744','18437');

 

select projectid, functionalSize, normalisedworkeffort from statsprojet where languagetype = '4GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0' and dataqualityrating in ('A','B');

select projectid,dataqualityrating,functionalSize, normalisedworkeffort from statsprojet where languagetype = '3GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0';

select * from statsprojet where languagetype = '4GL' and typeofserver like '%LAN%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0';
select * from statsprojet where projectid = '13437';


select projectid,functionalSize, normalisedworkeffort from statsprojet where languagetype = '3GL' and typeofserver like '%Unix%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0' and dataqualityrating in ('A','B');
select PrimaryProgrammingLanguage,FirstLanguage,SecondLanguage,FirstOperatingSystem,SecondOperatingSystem,DevelopmentTechniques from statsprojet where languagetype = '4GL' and typeofserver like '%LAN%' and CountApproach in ('COSMIC-FFP', 'IFPUG') and functionalSize != '0' and dataqualityrating in ('A','B') and projectid in ( '18245','16211','12939','16307','29491','18618','18593','18268','32166','31360','19165','23142','30803','26548');
select developmenttechniques  from statsprojet where projectid in ('26543','23358','25486','29665','13437','18203','25486');


Planning:Specification:Build:Test:Implement: 
Transaction/Production System: 
select * from statsprojet where projectid in ('21603','16764','16725','11749','26068','22814','25741','17639','26341','22129','31816','15449','31326','20471','31244','16796','25593','31420','29291','17744','18437','13511','13437');
